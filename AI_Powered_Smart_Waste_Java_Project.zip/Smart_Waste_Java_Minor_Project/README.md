# AI-Powered Smart Waste Identification, Disposal and Impact Tracking

## Contents
- `Main.java` — runnable Java console prototype
- `REPORT_GUIDE.md` — report structure and documentation guide
- `TEST_CASES.md` — suggested test cases

## Requirements
- JDK 17 or later
- Terminal / Command Prompt

## Run on Windows
1. Install a JDK and confirm `java -version` and `javac -version` work.
2. Open Command Prompt in this folder.
3. Compile: `javac Main.java`
4. Run: `java Main`

## Features
- Rule-based text waste classification
- Disposal guidance
- Add and view waste records
- Collection status updates
- Basic impact summary
- Input validation and exception handling
- Classes, objects, encapsulation, inheritance and polymorphism

## Honest limitations
This is an educational prototype. It does not use a trained machine-learning model or image recognition. Records are stored in memory and disappear when the program exits. The category totals are estimates based on the records entered; they do not verify actual recycling or calculate carbon savings. Authentication, persistent storage, image AI and live collection scheduling are future enhancements.
