# Test Cases — Run and record actual outcomes

| ID | Test | Expected outcome | Actual result |
|---|---|---|---|
| TC01 | Add “plastic bottle”, quantity 2.5, location “Campus” | Plastic record created | Fill after execution |
| TC02 | Identify “vegetable scraps” | Organic category | Fill after execution |
| TC03 | Identify “old newspaper” | Paper category | Fill after execution |
| TC04 | Enter quantity -5 | Rejected; asks again | Fill after execution |
| TC05 | Enter quantity abc | Number format handled; asks again | Fill after execution |
| TC06 | Leave description blank | Rejected; asks again | Fill after execution |
| TC07 | View records before adding any | “No records available yet.” | Fill after execution |
| TC08 | Mark existing record collected | Status becomes COLLECTED | Fill after execution |
| TC09 | Update unknown record ID | “Record ID not found.” | Fill after execution |
| TC10 | Generate impact report | Totals reflect entered session records | Fill after execution |
