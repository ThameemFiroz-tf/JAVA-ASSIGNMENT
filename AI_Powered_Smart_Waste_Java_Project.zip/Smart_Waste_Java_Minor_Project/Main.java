import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * AI-Powered Smart Waste Identification, Disposal and Impact Tracking
 * Educational prototype: classification is rule-based, not a trained AI model.
 * Requires Java 17 or later. Run: javac Main.java && java Main
 */
public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final List<Waste> records = new ArrayList<>();
    private static int nextId = 1;

    public static void main(String[] args) {
        System.out.println("==============================================");
        System.out.println(" SMART WASTE IDENTIFICATION AND TRACKING");
        System.out.println(" Educational prototype - rule-based classifier");
        System.out.println("==============================================");
        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Enter choice: ");
            switch (choice) {
                case 1 -> addWaste();
                case 2 -> identifyWaste();
                case 3 -> viewRecords();
                case 4 -> updateCollection();
                case 5 -> showImpactReport();
                case 6 -> showDisposalGuide();
                case 0 -> {
                    running = false;
                    System.out.println("Thank you for using Smart Waste Management.");
                }
                default -> System.out.println("Invalid choice. Please select 0 to 6.");
            }
        }
        SC.close();
    }

    private static void printMenu() {
        System.out.println("\\n--------------- MAIN MENU ----------------");
        System.out.println("1. Add waste record");
        System.out.println("2. Identify waste from description");
        System.out.println("3. View all waste records");
        System.out.println("4. Update collection status");
        System.out.println("5. Environmental impact report");
        System.out.println("6. Disposal guidance");
        System.out.println("0. Exit");
    }

    private static void addWaste() {
        System.out.println("\\n--- Add Waste Record ---");
        String description = readNonBlank("Waste description: ");
        double quantity = readPositiveDouble("Quantity in kg: ");
        String location = readNonBlank("Location: ");
        WasteCategory category = WasteClassifier.classify(description);
        Waste item;
        if (category == WasteCategory.ORGANIC) {
            item = new OrganicWaste(nextId++, description, quantity, location);
        } else if (category == WasteCategory.PLASTIC || category == WasteCategory.PAPER
                || category == WasteCategory.GLASS || category == WasteCategory.METAL) {
            item = new RecyclableWaste(nextId++, description, quantity, location, category);
        } else {
            item = new Waste(nextId++, description, quantity, location, category);
        }
        records.add(item);
        System.out.println("Record added successfully.");
        System.out.println("Record ID: " + item.getId());
        System.out.println("Category: " + item.getCategory());
        System.out.println("Disposal advice: " + item.getDisposalAdvice());
    }

    private static void identifyWaste() {
        String description = readNonBlank("Enter waste description: ");
        WasteCategory category = WasteClassifier.classify(description);
        System.out.println("Identified category: " + category);
        System.out.println("Recommended action: " + DisposalManager.adviceFor(category));
        if (category == WasteCategory.OTHER) {
            System.out.println("Note: Category uncertain. Verify locally before disposal.");
        }
    }

    private static void viewRecords() {
        System.out.println("\\n--- Waste Records ---");
        if (records.isEmpty()) {
            System.out.println("No records available yet.");
            return;
        }
        for (Waste item : records) {
            System.out.printf("ID: %d | Description: %s | Category: %s | %.2f kg | Location: %s | Status: %s%n",
                    item.getId(), item.getDescription(), item.getCategory(),
                    item.getQuantityKg(), item.getLocation(), item.getCollectionStatus());
        }
    }

    private static void updateCollection() {
        if (records.isEmpty()) {
            System.out.println("No records available. Add a record first.");
            return;
        }
        int id = readInt("Enter record ID to mark as collected: ");
        for (Waste item : records) {
            if (item.getId() == id) {
                item.markCollected();
                System.out.println("Collection status updated for record " + id + ".");
                return;
            }
        }
        System.out.println("Record ID not found.");
    }

    private static void showImpactReport() {
        double total = 0, recycled = 0, organic = 0, collected = 0;
        for (Waste item : records) {
            total += item.getQuantityKg();
            if (item.getCategory() == WasteCategory.PLASTIC
                    || item.getCategory() == WasteCategory.PAPER
                    || item.getCategory() == WasteCategory.GLASS
                    || item.getCategory() == WasteCategory.METAL) {
                recycled += item.getQuantityKg();
            }
            if (item.getCategory() == WasteCategory.ORGANIC) organic += item.getQuantityKg();
            if (item.getCollectionStatus().equals("COLLECTED")) collected += item.getQuantityKg();
        }
        System.out.println("\\n======= ENVIRONMENTAL IMPACT REPORT =======");
        System.out.printf("Total recorded waste : %.2f kg%n", total);
        System.out.printf("Potential recyclable  : %.2f kg%n", recycled);
        System.out.printf("Organic waste         : %.2f kg%n", organic);
        System.out.printf("Waste collected       : %.2f kg%n", collected);
        System.out.println("Note: 'Potential recyclable' is a category total, not proof of actual recycling.");
        System.out.println("No carbon-emission reduction is claimed by this prototype.");
        System.out.println("===========================================");
    }

    private static void showDisposalGuide() {
        System.out.println("\\n--- Disposal Guidance ---");
        for (WasteCategory category : WasteCategory.values()) {
            System.out.println(category + ": " + DisposalManager.adviceFor(category));
        }
        System.out.println("Always follow local municipal rules and specialist guidance.");
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = SC.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException ex) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = SC.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (Double.isFinite(value) && value > 0) return value;
                System.out.println("Quantity must be a positive number.");
            } catch (NumberFormatException ex) {
                System.out.println("Invalid quantity. Example: 2.5");
            }
        }
    }

    private static String readNonBlank(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = SC.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("This field cannot be blank.");
        }
    }
}

enum WasteCategory {
    ORGANIC, PLASTIC, PAPER, GLASS, METAL, ELECTRONIC, OTHER
}

class Waste {
    private final int id;
    private final String description;
    private final double quantityKg;
    private final String location;
    private final WasteCategory category;
    private String collectionStatus;

    public Waste(int id, String description, double quantityKg, String location, WasteCategory category) {
        if (description == null || description.isBlank()) {
            throw new IllegalArgumentException("Description cannot be blank.");
        }
        if (!Double.isFinite(quantityKg) || quantityKg <= 0) {
            throw new IllegalArgumentException("Quantity must be positive.");
        }
        this.id = id;
        this.description = description;
        this.quantityKg = quantityKg;
        this.location = location;
        this.category = category;
        this.collectionStatus = "PENDING";
    }

    public int getId() { return id; }
    public String getDescription() { return description; }
    public double getQuantityKg() { return quantityKg; }
    public String getLocation() { return location; }
    public WasteCategory getCategory() { return category; }
    public String getCollectionStatus() { return collectionStatus; }
    public void markCollected() { collectionStatus = "COLLECTED"; }

    public String getDisposalAdvice() {
        return DisposalManager.adviceFor(category);
    }
}

class OrganicWaste extends Waste {
    public OrganicWaste(int id, String description, double quantityKg, String location) {
        super(id, description, quantityKg, location, WasteCategory.ORGANIC);
    }

    @Override
    public String getDisposalAdvice() {
        return "Use a suitable composting or local organic-waste collection service.";
    }
}

class RecyclableWaste extends Waste {
    public RecyclableWaste(int id, String description, double quantityKg, String location,
                           WasteCategory category) {
        super(id, description, quantityKg, location, category);
    }

    @Override
    public String getDisposalAdvice() {
        return "Keep separated, clean where appropriate, and send to an accepted recycling facility.";
    }
}

class WasteClassifier {
    public static WasteCategory classify(String input) {
        String s = input.toLowerCase();
        if (containsAny(s, "vegetable", "fruit", "food", "leaves", "garden", "eggshell", "organic")) {
            return WasteCategory.ORGANIC;
        }
        if (containsAny(s, "glass", "jar", "glass bottle")) return WasteCategory.GLASS;
        if (containsAny(s, "plastic", "plastic bottle", "wrapper", "polythene")) return WasteCategory.PLASTIC;
        if (containsAny(s, "paper", "cardboard", "newspaper", "carton")) return WasteCategory.PAPER;
        if (containsAny(s, "metal", "aluminium", "aluminum", "tin can", "steel")) return WasteCategory.METAL;
        if (containsAny(s, "battery", "mobile phone", "laptop", "electronic", "charger", "circuit")) {
            return WasteCategory.ELECTRONIC;
        }
        return WasteCategory.OTHER;
    }

    private static boolean containsAny(String input, String... words) {
        for (String word : words) {
            if (input.contains(word)) return true;
        }
        return false;
    }
}

class DisposalManager {
    public static String adviceFor(WasteCategory category) {
        return switch (category) {
            case ORGANIC -> "Use a suitable composting or local organic-waste collection service.";
            case PLASTIC -> "Check the resin/local rules; send accepted clean plastic to recycling.";
            case PAPER -> "Keep dry and send clean paper/cardboard to paper recycling.";
            case GLASS -> "Use a designated glass collection point; handle broken glass safely.";
            case METAL -> "Separate and send accepted metal items to a recycling facility.";
            case ELECTRONIC -> "Use an authorized e-waste collection centre; do not mix with household waste.";
            case OTHER -> "Check local municipal guidance; do not assume this item is recyclable.";
        };
    }
}
