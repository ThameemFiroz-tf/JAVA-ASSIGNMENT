# AI-Powered Smart Waste Identification, Disposal and Impact Tracking
## Minor Project Report Guide — CS25C09 Java Programming

**Student name:** ____________________  
**Register number:** ____________________  
**Department:** Artificial Intelligence and Data Science  
**College:** SRM TRP Engineering College, Tiruchirappalli  
**Academic year:** 2026–2027  

## Phase I — Analysis and Design

### 1. Abstract
Improper waste disposal contributes to pollution, landfill accumulation and resource wastage. This project presents a Java application for classifying common waste descriptions, recommending disposal actions, recording waste quantities and collection status, and preparing a basic environmental impact summary. The prototype uses rule-based classification and object-oriented design. It is a foundation for future image-based machine learning, persistent storage and integration with municipal collection services.

### 2. Introduction
Waste materials require different handling methods. A simple digital system can help users record waste and find general disposal guidance. This project demonstrates how Java and object-oriented programming can organize waste records and summaries.

### 3. Problem Statement
Manual waste segregation and record keeping may lead to incorrect classification, poor tracking and difficulty reporting recycling quantities. A system is needed to classify common waste descriptions, provide disposal guidance, record collection status and summarize recorded quantities.

### 4. Objectives and Scope
- Classify common waste categories from text descriptions.
- Suggest general disposal guidance.
- Record quantity and location.
- Update collection status.
- Summarize total, potentially recyclable, organic and collected waste.
- Demonstrate Java classes, inheritance, polymorphism, encapsulation and exception handling.

Scope: This version is a console-based prototype. It does not perform image recognition, use live sensors, authenticate users or save records between runs.

### 5. Existing System and Limitations
Manual processes may use paper records or informal decisions. They can be inconsistent, difficult to summarize and hard to audit. Local disposal rules also vary by location.

### 6. Proposed System
The Java prototype accepts descriptions and quantities, classifies common waste using predefined keywords, recommends disposal guidance, stores records for the current session and calculates a basic summary.

### 7. Hardware and Software Requirements
- Computer running Windows, Linux or macOS
- 4 GB RAM minimum recommended
- JDK 17 or later
- VS Code, IntelliJ IDEA, Eclipse or another Java IDE
- Git/GitHub for source-code versioning

### 8. System Design and Class Diagram
Main flow: User input → validation → WasteClassifier → Waste record → Disposal guidance / collection status → Impact report.

Classes: `Waste`, `OrganicWaste`, `RecyclableWaste`, `WasteClassifier`, `DisposalManager`, and `Main`. `WasteCategory` is an enum.

### 9. Identification of Java and OOP Concepts
- Class and object: `Waste` records.
- Encapsulation: private fields and public methods.
- Inheritance: `OrganicWaste` and `RecyclableWaste` extend `Waste`.
- Polymorphism: subclasses override `getDisposalAdvice()`.
- Exception handling: `NumberFormatException` is handled for invalid numeric input.
- Collections: `ArrayList<Waste>` stores records.
- Enum: `WasteCategory` defines supported categories.
- Input validation: rejects blank fields and non-positive quantities.

### 10. Module Description
1. Waste identification: keyword-based classification.
2. Disposal guidance: category-specific general suggestions.
3. Collection management: mark a record as collected.
4. Impact tracking: summarize quantities recorded in the session.
5. Reporting: print a console report.
6. User/admin management: not implemented in this prototype; future enhancement.

## Phase II — Implementation and Testing

### 1. System Implementation
The application is implemented in Java and runs in a terminal. Compile using `javac Main.java` and execute using `java Main`.

### 2. Class and Object Implementation
Each accepted waste entry creates an object of `Waste`, `OrganicWaste`, or `RecyclableWaste`.

### 3. Inheritance, Polymorphism and Encapsulation
Subclasses inherit common fields and methods from `Waste`; overridden disposal advice demonstrates runtime polymorphism. Private fields protect record state.

### 4. Smart Disposal and Collection Module
The program displays disposal guidance and allows the user to mark a record as collected.

### 5. Environmental Impact Tracking Module
The report summarizes total recorded waste, potential recyclable category totals, organic waste and collected waste. These are record-based estimates, not verified environmental outcomes.

### 6. Exception Handling and Input Validation
Invalid numbers are caught and requested again. Blank descriptions and non-positive quantities are rejected.

### 7. Java Program Code
Attach or include the complete contents of `Main.java` in the final report appendix.

### 8. Testing and Test Cases
Use `TEST_CASES.md`. Record the actual result after running every test.

### 9. Sample Outputs and Screenshots
Run the program and capture genuine screenshots of: main menu, adding a waste record, invalid quantity handling, record list, collection status update and impact report. Do not label illustrative output as a real screenshot.

### 10. Results and Discussion
Describe which functions worked during testing. State limitations clearly: keyword-based classification may be wrong for unfamiliar descriptions; data is not persisted; impact summaries depend on user-entered values.

### 11. Conclusion and Future Enhancements
The prototype demonstrates a Java-based workflow for waste classification, disposal guidance, collection status and summary reporting. Future work can add a trained image classifier, secure role-based login, file/database persistence, location-aware collection scheduling, and validated environmental metrics.

### 12. References
1. Oracle. *Java Documentation*. https://docs.oracle.com/en/java/
2. Oracle. *Java Tutorials / Learning Paths*. https://dev.java/learn/
3. United Nations. *Sustainable Development Goals*. https://sdgs.un.org/goals
4. United Nations Sustainable Development Goal 12: Responsible Consumption and Production. https://sdgs.un.org/goals/goal12

### SDG Relevance
The project is aligned conceptually with **SDG 12: Responsible Consumption and Production**, especially reducing waste generation through prevention, reduction, recycling and reuse. The report should describe this as an intended contribution, not a measured impact unless validated data is available.
